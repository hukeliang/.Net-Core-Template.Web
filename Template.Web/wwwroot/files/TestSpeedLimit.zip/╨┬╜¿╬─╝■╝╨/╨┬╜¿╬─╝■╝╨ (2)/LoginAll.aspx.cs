﻿using BLL;
using Common;
using DAL;
using Model;
using System;
using System.Data;
using System.Linq;
using System.Web.UI;

public partial class Admin_LoginAll : System.Web.UI.Page
{
    protected string flag;
    protected string sty = "";
    protected string []imgpath;
    protected void Page_Load(object sender, EventArgs e)
    {      
        imgpath = new string[24];
        string imgRoot = "";
        if (Request.QueryString["flag"] != null && !string.IsNullOrEmpty(Request.QueryString["flag"].ToString()))
        {
            sty = Request.QueryString["flag"].ToString();
        }
        sty = sty.Trim().ToLower();
        switch (sty)
        {
            case "sz":
                imgRoot = "images/SZ/SZ_{0}.jpg";
                break;
            case "de":
                imgRoot = "DE/images/DE/DE_{0}.jpg";
                break;
            case "us":
                imgRoot = "US/images/US/US_{0}.jpg";
                break;
            case "cn":
                imgRoot = "CN/images/CN/CN_{0}.jpg";
                break;
            default:
                imgRoot = "images/HK/HK_{0}.jpg";
                break;

        }
        for (int i = 1; i <= imgpath.Length; i++)
        {
            imgpath[i - 1] = string.Format(imgRoot, i.ToString("00"));
        }

        if (Request.QueryString["Isquit"] == null)
        {
            Session["user"] = "";
            Session["flag"] = "";
            Session["szuser"] = "";
            Session["szflag"] = "";
        }
       
        if (!IsPostBack)
        {         
            if (sty == "hk" || sty == "sz")
            {
                AvaliablePrice_HK();
                SellOutCheck();
            }
        }
    }

    protected void login_Click(object sender, ImageClickEventArgs e)
    {
        sty = "hk";
        UserLog UL = new UserLog();
        UL.UserName = Username.Value.ToString().Trim().ToLower();
        UL.PassWord = Password.Value.ToString().Trim();

        string stLoginType = "";
        if (!string.IsNullOrEmpty(Request.Form["logintype"].ToString()))
        {
            stLoginType = Request.Form["logintype"].ToString().Trim().ToLower();
        }

        if (!string.IsNullOrEmpty(Request.Form["logincty"].ToString()))
        {
            sty = Request.Form["logincty"].ToString().Trim();
        }

        LoginBLL Lbll = new LoginBLL();
        DataTable dt = Lbll.CheckEmployeeUserMultCountry(UL,sty);
        if (dt.Rows.Count <= 0)
        {
            Response.Write("<script>alert('用户名或密码错误！')</script>");
        }
        else if (stLoginType != "ukey" && stLoginType != "app" && dt.Columns.Contains("LoginWeb") && dt.Rows[0]["LoginWeb"].ToString().ToLower() == "false")
        {
            Response.Write("<script>alert('该用户不允许使用Web方式登入,请联系管理员！')</script>");
        }
        else if (stLoginType == "ukey" && dt.Columns.Contains("LoginUKey") && dt.Rows[0]["LoginUKey"].ToString().ToLower() == "false")
        {
            Response.Write("<script>alert('该用户不允许使用UKey方式登入,请联系管理员！')</script>");
        }
        else if (stLoginType == "app" && dt.Columns.Contains("LoginApp") && dt.Rows[0]["LoginApp"].ToString().ToLower() == "false")
        {
            Response.Write("<script>alert('该用户不允许使用App方式登入,请联系管理员！')</script>");
        }
        else
        {
            try
            {
                GetIP getip = new GetIP();
                LoginRecordtbModel loginrecordtbmodel = new LoginRecordtbModel();
                loginrecordtbmodel.UserName = Username.Value.ToString().Trim().ToLower();
                loginrecordtbmodel.UserIP = GetIP.IPAddress;
                loginrecordtbmodel.Mark = sty.ToUpper();
                loginrecordtbmodel.InDate = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                LoginRecordtb loginrecordtb = new LoginRecordtb();
                loginrecordtb.LoginRecordAdd(loginrecordtbmodel);

                Session["user"] = Username.Value.ToString().Trim().ToLower();
                if (dt.Columns.Contains("LoginHK") && dt.Rows[0]["LoginHK"].ToString().ToLower() == "true")
                {
                    Session["flag"] = "hk";
                }
                if (dt.Columns.Contains("LoginSZ") && dt.Rows[0]["LoginSZ"].ToString().ToLower() == "true")
                {
                    Session["szuser"] = Username.Value.ToString().Trim().ToLower();
                    Session["szflag"] = "sz";
                }              
            }
            catch { }          
            switch (sty.ToLower())
            {
                case "sz":
                    Response.Redirect("sz/szLoginDefault.aspx");
                    break;            
                case "de":
                    Response.Redirect("de/LoginDefault.aspx");
                    break;
                case "us":
                    Response.Redirect("us/LoginDefault.aspx");
                    break;
                case "cn":
                    Response.Redirect("cn/LoginDefault.aspx");
                    break;
                default:  //hk
                    DataTable Mtb = Lbll.SelectModifyDate(UL);
                    //任意时间取前一个月
                    DateTime DateTimeNow = DateTime.Now;
                    DateTime ModifyDate = DateTime.Parse(Mtb.Rows[0]["ModifyDate"].ToString());
                    DateTime dateTime = DateTimeNow.AddMonths(-3);
                    if (ModifyDate < dateTime)
                    {
                        Response.Redirect("hk/hkLoginDefault.aspx?isok=no");
                    }
                    else
                    {
                        Response.Redirect("hk/hkLoginDefault.aspx?isok=yes");
                    }
                   break;
            }                                                      
        }
    }

    #region 执行预设价格更新
    //执行预设价格更新
    private void AvaliablePrice_HK()
    {
        HKPriceAutoBLL pad = new HKPriceAutoBLL();
        HKPriceAutoDAL had = new HKPriceAutoDAL();
        //HK預計生效價格
        DataTable dt1 = pad.SelectByMarkAndCurrentDay();
        if (dt1.Rows.Count > 0)
        {
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                string itemno = dt1.Rows[i]["ItemNo"].ToString();
                PriceBLL pbll = new PriceBLL();
                DataTable dtPrice1 = pbll.SelectByItemNo(itemno);
                if (dtPrice1.Rows.Count > 0)
                {
                    //添加历史价格记录
                    HKPriceHistory ph = new HKPriceHistory();
                    ph.ItemNo = dtPrice1.Rows[0]["ItemNo"].ToString();
                    ph.Price1 = Convert.ToDouble(dtPrice1.Rows[0]["Price1"].ToString());
                    ph.Price2 = Convert.ToDouble(dtPrice1.Rows[0]["Price2"].ToString());
                    ph.Price3 = Convert.ToDouble(dtPrice1.Rows[0]["Price3"].ToString());
                    ph.AirMail = Convert.ToDouble(dtPrice1.Rows[0]["Airmail"].ToString());
                    ph.Register = Convert.ToDouble(dtPrice1.Rows[0]["Register"].ToString());
                    ph.Ups = Convert.ToDouble(dtPrice1.Rows[0]["Ups"].ToString());
                    ph.HkPrice = Convert.ToDouble(dtPrice1.Rows[0]["HKPrice"].ToString());
                    ph.TheMan = "admin";
                    ph.AddDate = Convert.ToDateTime(DateTime.Now.ToString("d"));


                    //更新价格
                    HKPriceAutoBLL hkpa = new HKPriceAutoBLL();
                    DataTable dt11 = hkpa.SelectByItemnoOnly(itemno);
                    HKPrice p = new HKPrice();
                    p.Price1 = Convert.ToDouble(dt11.Rows[0]["Price1"].ToString());
                    p.Price2 = Convert.ToDouble(dt11.Rows[0]["Price2"].ToString());
                    p.Price3 = Convert.ToDouble(dt11.Rows[0]["Price3"].ToString());
                    p.Airmail = Convert.ToDouble(dt11.Rows[0]["Airmail"].ToString());
                    p.Register = Convert.ToDouble(dt11.Rows[0]["Register"].ToString());
                    p.HkPrice = Convert.ToDouble(dt11.Rows[0]["HKPrice"].ToString());
                    p.Ups = Convert.ToDouble(dt11.Rows[0]["Ups"].ToString());
                    p.ItemNo = itemno;
                    if (ph.Price1 != p.Price1 || ph.Price2 != p.Price2 || ph.Price3 != p.Price3 || ph.Register != p.Register || ph.AirMail != p.Airmail || ph.Ups != p.Ups || ph.HkPrice != p.HkPrice)
                    {
                        HKPriceHistoryBLL phb = new HKPriceHistoryBLL();
                        if ((ph.Price1 != p.Price1 && ph.Price1 != 0) || (ph.Price2 != p.Price2 && ph.Price2 != 0) || (ph.Price3 != p.Price3 && ph.Price3 != 0) || (ph.AirMail != p.Airmail && ph.AirMail != 0) || (ph.Register != p.Register && ph.Register != 0) || (ph.Ups != p.Ups && ph.Ups != 0) || (ph.HkPrice != p.HkPrice && ph.HkPrice != 0))
                        {
                            phb.AddHistory(ph, p);
                        }
                        pbll.UpdatePrice(p);

                        double rate = 1.047 * 1.19 * 0.76;
                        DEPrice priceDE = new DEPrice();
                        priceDE.Price1 = p.Price1 * rate;
                        priceDE.Price2 = p.Price2 * rate;
                        priceDE.Price3 = p.Price3 * rate;
                        priceDE.Airmail = p.Airmail * rate;
                        priceDE.Register = p.Register * rate;
                        priceDE.Ups = p.Ups * rate;
                        priceDE.ItemNo = p.ItemNo;
                        DEPriceBLL pbDe = new DEPriceBLL();
                        pbDe.UpdatePrice(priceDE);
                    }
                }
            }
            //更新Mark
            HKPriceAutoBLL hkpa1 = new HKPriceAutoBLL();
            int n = hkpa1.UpdateMarkByItemnoAndTime();
        }

        //US预计生效价格
        DataTable dtus = had.SelectByMarkAndCurrentDayUS();
        if (dtus.Rows.Count > 0)
        {
            for (int i = 0; i < dtus.Rows.Count; i++)
            {
                string itemno = dtus.Rows[i]["ItemNo"].ToString();
                PriceBLL pbll = new PriceBLL();
                PriceDAL pd = new PriceDAL();
                DataTable dtPrice1 = pbll.SelectByItemNoUS(itemno);
                if (dtPrice1.Rows.Count > 0)
                {
                    //添加历史价格记录
                    HKPriceHistory ph = new HKPriceHistory();
                    ph.ItemNo = dtPrice1.Rows[0]["ItemNo"].ToString();
                    ph.Price1 = Convert.ToDouble(dtPrice1.Rows[0]["Price1"].ToString());
                    ph.Price2 = Convert.ToDouble(dtPrice1.Rows[0]["USPrice"].ToString());
                    ph.Price3 = Convert.ToDouble(dtPrice1.Rows[0]["Price3"].ToString());
                    ph.AirMail = Convert.ToDouble(dtPrice1.Rows[0]["Airmail"].ToString());
                    ph.Register = Convert.ToDouble(dtPrice1.Rows[0]["Register"].ToString());
                    ph.Ups = Convert.ToDouble(dtPrice1.Rows[0]["Ups"].ToString());
                    ph.HkPrice = Convert.ToDouble(dtPrice1.Rows[0]["OnLinePrice"].ToString());
                    ph.TheMan = "admin";
                    ph.AddDate = Convert.ToDateTime(DateTime.Now.ToString("d"));

                    //更新价格
                    DataTable dt11 = had.SelectByItemnoOnlyUS(itemno);
                    UsPrice p = new UsPrice();
                    p.Price1 = Convert.ToDouble(dt11.Rows[0]["Price1"].ToString());
                    p.USPrice = Convert.ToDouble(dt11.Rows[0]["USPrice"].ToString());
                    p.Price3 = Convert.ToDouble(dt11.Rows[0]["Price3"].ToString());
                    p.Airmail = Convert.ToDouble(dt11.Rows[0]["Airmail"].ToString());
                    p.Register = Convert.ToDouble(dt11.Rows[0]["Register"].ToString());
                    p.OnLinePrice = Convert.ToDouble(dt11.Rows[0]["OnLinePrice"].ToString());
                    p.Ups = Convert.ToDouble(dt11.Rows[0]["Ups"].ToString());
                    p.ItemNo = itemno;
                    if (ph.Price1 != p.Price1 || ph.Price2 != p.USPrice || ph.Price3 != p.Price3 || ph.Register != p.Register || ph.AirMail != p.Airmail || ph.Ups != p.Ups || ph.HkPrice != p.OnLinePrice)
                    {
                        HKPriceHistoryDAL phb = new HKPriceHistoryDAL();
                        if ((ph.Price1 != p.Price1 && ph.Price1 != 0) || (ph.Price2 != p.USPrice && ph.Price2 != 0) || (ph.Price3 != p.Price3 && ph.Price3 != 0) || (ph.AirMail != p.Airmail && ph.AirMail != 0) || (ph.Register != p.Register && ph.Register != 0) || (ph.Ups != p.Ups && ph.Ups != 0) || (ph.HkPrice != p.OnLinePrice && ph.HkPrice != 0))
                        {
                            phb.AddHistoryUS(ph, p);
                        }
                        pd.UpdatePriceUS(p);
                    }
                }
            }
            //更新Mark
            int us = had.UpdateMarkByItemnoAndTimeUS();
        }

        //DE预计生效价格
        DataTable dtde = had.SelectByMarkAndCurrentDayDE();
        if (dtde.Rows.Count > 0)
        {
            for (int i = 0; i < dtde.Rows.Count; i++)
            {
                string itemno = dtde.Rows[i]["ItemNo"].ToString();
                PriceBLL pbll = new PriceBLL();
                PriceDAL pd = new PriceDAL();
                DataTable dtPrice1 = pbll.SelectByItemNoDE(itemno);
                if (dtPrice1.Rows.Count > 0)
                {
                    //添加历史价格记录
                    HKPriceHistory ph = new HKPriceHistory();
                    ph.ItemNo = dtPrice1.Rows[0]["ItemNo"].ToString();
                    ph.Price1 = Convert.ToDouble(dtPrice1.Rows[0]["Price1"].ToString());
                    ph.Price2 = Convert.ToDouble(dtPrice1.Rows[0]["Price2"].ToString());
                    ph.Price3 = Convert.ToDouble(dtPrice1.Rows[0]["Price3"].ToString());
                    ph.AirMail = Convert.ToDouble(dtPrice1.Rows[0]["Shipment1"].ToString());
                    ph.Register = Convert.ToDouble(dtPrice1.Rows[0]["Shipment2"].ToString());
                    ph.Ups = Convert.ToDouble(dtPrice1.Rows[0]["Shipment3"].ToString());
                    ph.HkPrice = Convert.ToDouble(dtPrice1.Rows[0]["DEPrice"].ToString());
                    ph.TheMan = "admin";
                    ph.AddDate = Convert.ToDateTime(DateTime.Now.ToString("d"));

                    //更新价格
                    DataTable dt11 = had.SelectByItemnoOnlyDE(itemno);
                    DEPrice p = new DEPrice();
                    p.Price1 = Convert.ToDouble(dt11.Rows[0]["Price1"].ToString());
                    p.Price2 = Convert.ToDouble(dt11.Rows[0]["Price2"].ToString());
                    p.Price3 = Convert.ToDouble(dt11.Rows[0]["Price3"].ToString());
                    p.Airmail = Convert.ToDouble(dt11.Rows[0]["Airmail"].ToString());
                    p.Register = Convert.ToDouble(dt11.Rows[0]["Register"].ToString());
                    p.DePrice = Convert.ToDouble(dt11.Rows[0]["DEPrice"].ToString());
                    p.Ups = Convert.ToDouble(dt11.Rows[0]["Ups"].ToString());
                    p.ItemNo = itemno;
                    if (ph.Price1 != p.Price1 || ph.Price2 != p.Price2 || ph.Price3 != p.Price3 || ph.Register != p.Register || ph.AirMail != p.Airmail || ph.Ups != p.Ups || ph.HkPrice != p.DePrice)
                    {
                        HKPriceHistoryDAL phb = new HKPriceHistoryDAL();
                        if ((ph.Price1 != p.Price1 && ph.Price1 != 0) || (ph.Price2 != p.Price2 && ph.Price2 != 0) || (ph.Price3 != p.Price3 && ph.Price3 != 0) || (ph.AirMail != p.Airmail && ph.AirMail != 0) || (ph.Register != p.Register && ph.Register != 0) || (ph.Ups != p.Ups && ph.Ups != 0) || (ph.HkPrice != p.DePrice && ph.HkPrice != 0))
                        {
                            phb.AddHistoryDE(ph, p);
                        }
                        pd.UpdatePriceDE(p);
                    }
                }
            }
            //更新Mark
            int de = had.UpdateMarkByItemnoAndTimeDE();
        }

        //UK预计生效价格
        DataTable dtuk = had.SelectByMarkAndCurrentDayUK();
        if (dtuk.Rows.Count > 0)
        {
            for (int i = 0; i < dtuk.Rows.Count; i++)
            {
                string itemno = dtuk.Rows[i]["ItemNo"].ToString();
                PriceBLL pbll = new PriceBLL();
                PriceDAL pd = new PriceDAL();
                DataTable dtPrice1 = pbll.SelectByItemNoUK(itemno);
                if (dtPrice1.Rows.Count > 0)
                {
                    //添加历史价格记录
                    HKPriceHistory ph = new HKPriceHistory();
                    ph.ItemNo = dtPrice1.Rows[0]["ItemNo"].ToString();
                    ph.Price1 = Convert.ToDouble(dtPrice1.Rows[0]["Price1"].ToString());
                    ph.Price2 = Convert.ToDouble(dtPrice1.Rows[0]["Price2"].ToString());
                    ph.Price3 = Convert.ToDouble(dtPrice1.Rows[0]["Price3"].ToString());
                    ph.AirMail = Convert.ToDouble(dtPrice1.Rows[0]["Airmail"].ToString());
                    ph.Register = Convert.ToDouble(dtPrice1.Rows[0]["Register"].ToString());
                    ph.Ups = Convert.ToDouble(dtPrice1.Rows[0]["Ups"].ToString());
                    ph.HkPrice = Convert.ToDouble(dtPrice1.Rows[0]["UKPrice"].ToString());
                    ph.TheMan = "admin";
                    ph.AddDate = Convert.ToDateTime(DateTime.Now.ToString("d"));

                    //更新价格
                    DataTable dt11 = had.SelectByItemnoOnlyUK(itemno);
                    UkPrice p = new UkPrice();
                    p.Price1 = Convert.ToDouble(dt11.Rows[0]["Price1"].ToString());
                    p.Price2 = Convert.ToDouble(dt11.Rows[0]["Price2"].ToString());
                    p.Price3 = Convert.ToDouble(dt11.Rows[0]["Price3"].ToString());
                    p.Airmail = Convert.ToDouble(dt11.Rows[0]["Airmail"].ToString());
                    p.Register = Convert.ToDouble(dt11.Rows[0]["Register"].ToString());
                    p.UKPrice = Convert.ToDouble(dt11.Rows[0]["UKPrice"].ToString());
                    p.Ups = Convert.ToDouble(dt11.Rows[0]["Ups"].ToString());
                    p.ItemNo = itemno;
                    if (ph.Price1 != p.Price1 || ph.Price2 != p.Price2 || ph.Price3 != p.Price3 || ph.Register != p.Register || ph.AirMail != p.Airmail || ph.Ups != p.Ups || ph.HkPrice != p.UKPrice)
                    {
                        HKPriceHistoryDAL phb = new HKPriceHistoryDAL();
                        if ((ph.Price1 != p.Price1 && ph.Price1 != 0) || (ph.Price2 != p.Price2 && ph.Price2 != 0) || (ph.Price3 != p.Price3 && ph.Price3 != 0) || (ph.AirMail != p.Airmail && ph.AirMail != 0) || (ph.Register != p.Register && ph.Register != 0) || (ph.Ups != p.Ups && ph.Ups != 0) || (ph.HkPrice != p.UKPrice && ph.HkPrice != 0))
                        {
                            phb.AddHistoryUK(ph, p);
                        }
                        pd.UpdatePriceUK(p);
                    }
                }
            }
            //更新Mark
            int de = had.UpdateMarkByItemnoAndTimeDE();
        }

    }
    #endregion

    #region 检测售完即止
    private void SellOutCheck()
    {
        PriceBLL pcBLL = new PriceBLL();

        var SelloutIE = pcBLL.SearchSellOutSZAndHKItemNoBLL();
        var SelloutIESZ = pcBLL.SearchSellOutSZAndHKBLL("SZ");
        var SelloutIEHK = pcBLL.SearchSellOutSZAndHKBLL("HK");

        int number = 0;
        string itemNoTotal = "";
        int SelloutIECount = SelloutIE.Count();

        if (SelloutIECount > 0)
        {

            DataTable remarkDt = new DataTable();
            foreach (var item in SelloutIE)
            {
                int hkStock = 0;
                int szStock = 0;
                string itemno = item.Field<string>("Sitemno");

                var SelloutIESZItem = SelloutIESZ.Where(row => itemno.Equals(row.Field<string>("Sitemno")));
                var SelloutIEHKItem = SelloutIEHK.Where(row => itemno.Equals(row.Field<string>("Sitemno")));

                foreach (var itemSz in SelloutIESZItem)
                {
                    szStock += itemSz.Field<int>("Squantity");
                }

                foreach (var itemHk in SelloutIEHKItem)
                {
                    szStock += itemHk.Field<int>("Squantity");
                }

                if ((hkStock + szStock) != 0) continue;

                itemNoTotal = itemNoTotal + itemno + ", ";
                remarkDt = pcBLL.SearchRemarkWAndRemarkEByItemnoBLL(itemno);   //查询网上备注和ERP备注
                if (remarkDt.Rows.Count > 0)
                {
                    for (int j = 0; j < remarkDt.Rows.Count; j++)
                    {
                        string remarkW = remarkDt.Rows[0]["RemarkW"].ToString().Trim();
                        string remarkE = remarkDt.Rows[0]["RemarkE"].ToString().Trim();
                        if (remarkW == "")                                    //网上备注为空
                        {
                            number = pcBLL.UpdateRemarkWByItemnoBLL(itemno);
                        }
                        else
                        {
                            number = pcBLL.UpdateRemarkWNoEmptyByItemnoBLL(itemno);
                        }
                        if (remarkE == "")                                  //ERP备注为空
                        {
                            number = pcBLL.UpdateRemarkEEmptyByItemnoBLL(itemno);
                        }
                        else
                        {
                            number = pcBLL.UpdateRemarkENoEmptyByItemnoBLL(itemno);
                        }
                    }
                }
            }
        }
    }
    #endregion
}
